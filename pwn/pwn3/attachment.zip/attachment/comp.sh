g++ -fsanitize=address -g -O2 -o attachment ./src.cpp
g++ -o runner ./runner.cpp